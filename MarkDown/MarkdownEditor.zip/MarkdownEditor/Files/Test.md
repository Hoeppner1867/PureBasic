﻿### MarkDown ###

> The gadget can display text formatted with the [MarkDown Syntax](https://www.markdownguide.org/basic-syntax/).  
> Markdown[^1] is a lightweight MarkUp language that you can use to add formatting elements to plaintext text documents.

- Markdown files can be read even if it isn’t rendered.
- Markdown is portable.
- Markdown is platform independent.

[^1]: Created by John Gruber in 2004.